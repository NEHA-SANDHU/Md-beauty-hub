<!--footer-->
    <div class="footer">
       <p>&copy; 2022 MD Beauty Hub Admin Panel.</p>
    </div>
        <!--//footer-->